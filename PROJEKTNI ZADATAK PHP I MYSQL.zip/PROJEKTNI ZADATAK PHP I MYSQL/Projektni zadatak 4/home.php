<!DOCTYPE html>
<html lang="hr">
    <main>
        <h1>DINAMO - DORTMUND 0:3 Borussia</h1>
        <figure>
            <img src="images/news1_1.jpg" alt="HTML5 Logo" width="300" height="150">
            <figcaption>DINAMO - DORTMUND 0:3 Borussia lako pobijedila Dinamo na Maksimiru </figcaption>
        </figure>
        <p>DINAMO je petom kolu Lige prvaka na Maksimiru izgubio 3:0 od Borussije Dortmund. Aktualni europski doprvak lako se obračunao s hrvatskim prvakom te poveo pred kraj prvog poluvremena pogotkom Jamieja Gittensa, da bi pobjedu u drugom dijelu podebljali Ramy Bensebaini i Serhou Guirassy.</p>
        <p>Momčad Nenada Bjelice tako je nakon ovog kola pala na 23. mjesto u poretku Lige prvaka sa sedam osvojenih bodova. Podsjetimo, najbolje 24 momčadi izborit će nastavak natjecanja. Dodajmo da su prvi Dinamovi pratitelji na tablici Real Madrid i Paris Saint-Germain.</p>
        <p>Dortmund je prvi put zaprijetio u osmoj minuti, kada se Ramy Bensebaini ubacio iz drugog plana i glavom uzdrmao gredu. Dinamo je nakon toga uglavnom uspješno odbijao nalete gostiju, koji su imali ogromnu nadmoć u posjedu lopte, dok je na drugoj strani pokušao biti opasan iz kontri.</p>
        <p>Ipak, obrana Dinama popustila je pred kraj prvog dijela. Danijel Zagorac je u 40. minuti izvrsnom obranom zaustavio pokušaj Donyella Malena iz velike blizine, ali samo minutu poslije bio je nemoćan kada je Jamie Gittens fantastičnim udarcem s ruba šesnaesterca pogodio za vodstvo Borussije.</p>
        <p>Source: Index</p>
        <div class="social">
            <a href="https://www.linkedin.com" target="_blank" title="LinkedIn">
                <img src="images/linkedin.png" alt="LinkedIn" />
            </a>
            <a href="https://facebook.com" target="_blank" title="Facebook">
                <img src="images/facebook.jpg" alt="Facebook" />
            </a>
            <a href="https://twitter.com" target="_blank" title="Twitter">
                <img src="images/twitter.svg" alt="Twitter" />
            </a>
        </div>
    </main>
</html>
