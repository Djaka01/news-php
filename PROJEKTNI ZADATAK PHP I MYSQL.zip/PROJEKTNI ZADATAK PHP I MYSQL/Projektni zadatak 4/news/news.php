<?php
global $conn;
include 'database.php';
// Dohvaćanje svih vijesti iz baze
$result = $conn->query("SELECT id, naslov, datum_unosa, tekst FROM Vijesti WHERE odobreno = 1 ORDER BY datum_unosa DESC");
$images_result = $conn->query("SELECT id, vijest_id, putanja_slike FROM Slike");

if ($result->num_rows > 0) {
    $articles = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $articles = [];
}

if ($images_result->num_rows > 0) {
    $images = $images_result->fetch_all(MYSQLI_ASSOC);
} else {
    $images = [];
}


?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Projektni zadatak 5 opis">
    <meta name="keywords" content="HTML5, css, projekt, zadatak">
    <meta name="author" content="Ivan Đakovac">
    <link rel="stylesheet" href="./news/news.css">
    <title>Projektni zadatak</title>
</head>
<h1>News</h1>
<section class="articles">
    <?php foreach ($articles as $article):
        $short_content = substr($article['tekst'], 0, 150);
        foreach ($images as $image):
            if ($image["vijest_id"] === $article["id"]) {
                $putanja_slike = $image["putanja_slike"];
            }
        endforeach;
        if (strlen($article['tekst']) > 150) {
            $short_content .= '...';
        }
    ?>
        <article>
            <img src="<?php echo htmlspecialchars($putanja_slike); ?>" alt="Article Image">
            <div>
                <h2><a href="?articleId=<?php echo $article['id'];?>"><?php echo htmlspecialchars($article['naslov']); ?></a></h2>
                <p class="date">Published: <?php echo htmlspecialchars($article['datum_unosa']); ?></p>
                <p><?php echo htmlspecialchars($short_content); ?></p>
                <a href="?articleId=<?php echo $article['id']; ?>" class="read-more">Read more...</a>
            </div>
        </article>
    <?php endforeach; ?>
</section>
