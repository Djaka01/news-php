<?php
global $conn;
include 'database.php';

// Dohvaćanje ID-a članka iz URL-a
$id = isset($_GET['articleId']) ? intval($_GET['articleId']) : 0;

// Dohvaćanje članka iz baze
$query = "SELECT naslov, datum_unosa, tekst FROM Vijesti WHERE id = $id AND odobreno = 1";
$images_result = $conn->query("SELECT id, vijest_id, putanja_slike FROM Slike  WHERE vijest_id = $id");

$result = $conn->query($query);

if ($result->num_rows > 0) {
    $current_article = $result->fetch_assoc();
    $sentences = preg_split('/(?<=[.!?])\s+/', $current_article['tekst'], -1, PREG_SPLIT_NO_EMPTY);
} else {
    $current_article = null;
}

if ($images_result->num_rows > 0) {
    $current_image = $images_result->fetch_assoc();
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Projektni zadatak 5 opis">
    <meta name="keywords" content="HTML5, css, projekt, zadatak">
    <meta name="author" content="Ivan Đakovac">
    <link rel="stylesheet" href="./news/news.css">
    <title>Projektni zadatak</title>
</head>
<body>
<?php if ($current_article): ?>
    <h1><?php echo htmlspecialchars($current_article['naslov']); ?></h1>
    <p class="date">Published: <?php echo htmlspecialchars($current_article['datum_unosa']); ?></p>
    <img src="<?php echo htmlspecialchars($current_image['putanja_slike']); ?>" alt="Article Image">
    <div class="content">
        <?php foreach ($sentences as $sentence): ?>
            <p><?php echo htmlspecialchars($sentence); ?></p>
        <?php endforeach; ?>
    </div>
    <a href="?menu=2" class="back-link">Back to News</a>
<?php else: ?>
    <h1>Article not found</h1>
    <p>We couldn't find the article you're looking for.</p>
    <a href="?menu=2" class="back-link">Back to News</a>
<?php endif; ?>
</body>
