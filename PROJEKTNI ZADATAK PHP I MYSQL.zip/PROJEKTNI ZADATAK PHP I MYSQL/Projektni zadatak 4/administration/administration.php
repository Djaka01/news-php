<?php
global $conn;
include('database.php');

session_start();

if (!isset($_SESSION['user_role'])) {
    echo "Access denied.";
    exit;
}

if (isset($_POST['update_role'])) {
    $user_id = $_POST['user_id'];
    $new_role = $_POST['new_role'];
    $conn->query("UPDATE Korisnik SET role='$new_role' WHERE id='$user_id'");
    echo "Uloga korisnika ažurirana.";
}

if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    $conn->query("DELETE FROM Korisnik WHERE id='$user_id'");
    echo "Korisnik obrisan.";
}

if (isset($_POST['add_news'])) {
    $naslov = $_POST['naslov'];
    $tekst = $_POST['tekst'];
    $odobreno = $_SESSION['user_role'] == 'user' ? 0 : 1; // Userove vijesti nisu automatski odobrene
    $conn->query("INSERT INTO Vijesti (naslov, tekst, odobreno) VALUES ('$naslov', '$tekst', '$odobreno')");
    echo "Vijest uspješno dodana.";
}

if (isset($_POST['upload_image'])) {
    $vijest_id = $_POST['vijest_id'];
    $upload_dir = './images/';
    $image_number = $conn->query("SELECT COUNT(*) AS count FROM Slike WHERE vijest_id = '$vijest_id'")->fetch_assoc()['count'] + 1;
    $image_name = "news{$vijest_id}_{$image_number}.jpg";
    $target_file = $upload_dir . $image_name;

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // Kreiraj direktorij ako ne postoji
    }

    if ($_FILES['news_image']['error'] === UPLOAD_ERR_OK) {
        $image_content = file_get_contents($_FILES['news_image']['tmp_name']);
        if (file_put_contents($target_file, $image_content)) {
            $stmt = $conn->prepare("INSERT INTO Slike (vijest_id, putanja_slike) VALUES (?, ?)");
            $stmt->bind_param("is", $vijest_id, $target_file);
            $stmt->execute();
            echo "Slika uspješno dodana.";
            $stmt->close();
        } else {
            echo "Greška pri spremanju slike u mapu.";
        }
    } else {
        echo "Greška pri prijenosu slike. Kod greške: " . $_FILES['news_image']['error'];
    }
}

if (isset($_POST['delete_image'])) {
    $image_id = $_POST['image_id'];
    $image = $conn->query("SELECT putanja_slike FROM Slike WHERE id = '$image_id'")->fetch_assoc();
    $image_path = $image['putanja_slike'];

    if (file_exists($image_path)) {
        unlink($image_path);
    }

    $conn->query("DELETE FROM Slike WHERE id = '$image_id'");
    echo "Slika obrisana.";
}

if (isset($_POST['delete_news'])) {
    $vijest_id = $_POST['vijest_id'];

    $result_images = $conn->query("SELECT putanja_slike FROM Slike WHERE vijest_id = '$vijest_id'");
    while ($image = mysqli_fetch_assoc($result_images)) {
        $image_path = $image['putanja_slike'];
        if (file_exists($image_path)) {
            unlink($image_path);
        }
    }

    $conn->query("DELETE FROM Slike WHERE vijest_id = '$vijest_id'");

    $conn->query("DELETE FROM Vijesti WHERE id = '$vijest_id'");

    echo "Vijest i povezane slike uspješno obrisane.";
}

if (isset($_POST['approve_news'])) {
    $vijest_id = $_POST['vijest_id'];

    $stmt = $conn->prepare("UPDATE Vijesti SET odobreno = 1 WHERE id = ?");
    $stmt->bind_param("i", $vijest_id);

    if ($stmt->execute()) {
        echo "Vijest je uspješno odobrena.";
    } else {
        echo "Greška prilikom odobravanja vijesti.";
    }

    $stmt->close();
}

$query_users = "SELECT id, korisnicko_ime, role FROM Korisnik";
$result_users = $conn->query($query_users);

$query_news = "SELECT * FROM Vijesti";
$result_news = $conn->query($query_news);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administracija</title>
    <link rel="stylesheet" href="./administration/administration.css">
</head>
<body>
<h1>Administracija korisnika</h1>
<table class="responsive-table">
    <thead>
    <tr>
        <th>ID</th>
        <th>Korisničko ime</th>
        <th>Role</th>
        <th>Akcije</th>
    </tr>
    </thead>
    <tbody>
    <?php while ($row = mysqli_fetch_assoc($result_users)): ?>
        <tr>
            <form method="POST">
                <td><?= $row['id'] ?></td>
                <td><?= $row['korisnicko_ime'] ?></td>
                <td>
                    <input type="hidden" name="user_id" value="<?= $row['id'] ?>" />
                    <select name="new_role">
                        <option value="none" <?= $row['role'] == null ? 'selected' : '' ?>>None</option>
                        <option value="user" <?= $row['role'] == 'user' ? 'selected' : '' ?>>User</option>
                        <option value="editor" <?= $row['role'] == 'editor' ? 'selected' : '' ?>>Editor</option>
                        <option value="administrator" <?= $row['role'] == 'administrator' ? 'selected' : '' ?>>Administrator</option>
                    </select>
                </td>
                <td>
                    <button type="submit" name="update_role">Promijeni</button>
                    <button type="submit" name="delete_user">Obriši</button>
                </td>
            </form>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<h1>Dodavanje nove vijesti</h1>
<form method="POST" class="form-container">
    <input type="text" name="naslov" placeholder="Naslov vijesti" required />
    <textarea name="tekst" placeholder="Tekst vijesti" required></textarea>
    <button type="submit" name="add_news">Dodaj vijest</button>
</form>

<h1>Upravljanje vijestima</h1>
<table class="responsive-table">
    <thead>
    <tr>
        <th>ID</th>
        <th>Naslov</th>
        <th>Tekst</th>
        <th>Datum</th>
        <th>Odobreno</th>
        <th>Slike</th>
        <th>Akcije</th>
    </tr>
    </thead>
    <tbody>
    <?php while ($row = mysqli_fetch_assoc($result_news)): ?>
        <tr>
            <form method="POST" enctype="multipart/form-data">
                <td><?= $row['id'] ?></td>
                <td><?= $row['arhiva'] ? "(Archived) " : "" ?><?= $row['naslov'] ?></td>
                <td><?= $row['tekst'] ?></td>
                <td><?= $row['datum_unosa'] ?></td>
                <td><?= $row['odobreno'] ? 'Da' : 'Ne' ?></td>
                <td>
                    <?php
                    $result_images = $conn->query("SELECT * FROM Slike WHERE vijest_id = '{$row['id']}'");
                    while ($image = mysqli_fetch_assoc($result_images)):
                        ?>
                        <div class="image-container">
                            <img src="<?= $image['putanja_slike'] ?>" alt="Slika vijesti" />
                            <form method="POST">
                                <input type="hidden" name="image_id" value="<?= $image['id'] ?>" />
                                <button type="submit" name="delete_image">Obriši sliku</button>
                            </form>
                        </div>
                    <?php endwhile; ?>
                </td>
                <td>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="vijest_id" value="<?= $row['id'] ?>" />
                        <button type="submit" name="toggle_archive"><?= $row['arhiva'] ? "Izvadi iz arhive" : "Arhiviraj" ?></button>
                        <?php if ($_SESSION['user_role'] == 'administrator' && !$row['odobreno']): ?>
                            <button type="submit" name="approve_news">Odobri</button>
                        <?php endif; ?>
                        <button type="submit" name="delete_news">Obriši vijest</button>
                        <input type="file" name="news_image" />
                        <button type="submit" name="upload_image">Dodaj sliku</button>
                    </form>
                </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
</body>
</html>
