<?php
global $conn;
include 'database.php';

session_start();
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./login/login.css">
    <title>Prijava</title>
</head>
<body>
<section class="contact-form">
    <h2>Forma za prijavu</h2>

    <?php
    if (!isset($_POST['_action_']) || $_POST['_action_'] == FALSE) {
        ?>
        <form action="" method="POST">
            <input type="hidden" name="_action_" value="TRUE">
            <input type="text" name="korisnicko_ime" placeholder="Korisničko ime" required>
            <input type="password" name="lozinka" placeholder="Lozinka" required>
            <button type="submit">Prijava</button>
        </form>
        <?php
    } else {
        $korisnicko_ime = $_POST['korisnicko_ime'];
        $lozinka = $_POST['lozinka'];

        $korisnicko_ime = $conn->real_escape_string($korisnicko_ime);

        $query = "SELECT id, lozinka, role FROM Korisnik WHERE korisnicko_ime = '$korisnicko_ime'";
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $id = $row['id'];
            $hashed_password = $row['lozinka'];
            $role = $row['role'];

            if (password_verify($lozinka, $hashed_password)) {
                echo "id:" .$id;
                $_SESSION['user_id'] = $id;
                $_SESSION['user_role'] = $role;
                echo "Session id:".$_SESSION["user_id"];
                echo "<p>Prijava uspješna!</p>";
                header("Location: ?menu=1");
            } else {
                echo "<p>Vaš račun još nije odobren od strane administratora!</p>";
            }
        } else {
            echo "<p>Vaš račun još nije odobren od strane administratora!</p>";
        }
    }
    ?>
</section>
</body>
</html>
