<?php
session_start();
// Define the menu variable based on the query parameter
$menu = isset($_GET['menu']) ? $_GET['menu'] : 1;
$article = isset($_GET['articleId']) ? $_GET['articleId'] : null;
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Projektni zadatak 5 opis">
    <meta name="keywords" content="HTML5, css, projekt, zadatak">
    <meta name="author" content="Ivan Đakovac">
    <link rel="stylesheet" href="style.css">
    <title>Projektni zadatak</title>
</head>
<body>
<header>
    <img src="images/image.png" alt="header-image">
    <nav>
        <ul>
            <li><a href="?menu=1">Home</a></li>
            <li><a href="?menu=2">News</a></li>
            <li><a href="?menu=3">Contact</a></li>
            <li><a href="?menu=4">About</a></li>
            <li><a href="?menu=5">Gallery</a></li>
            <?php
                if ($_SESSION['user_id'] != null) {
                    echo '<li><a href="?menu=8">Logout</a></li>';
                } else {
                    echo '<li><a href="?menu=6">Register</a></li>';
                    echo '<li><a href="?menu=7">Login</a></li>';
                }
            ?>


        </ul>
    </nav>
</header>
<main>
    <?php
    if ($article) {
        include './news/article.php';
    } else {
        switch ($menu) {
            case 1:
                include 'home.php';
                break;
            case 2:
                include './news/news.php';
                break;
            case 3:
                include './contact/contact.php';
                break;
            case 4:
                include './aboutus/aboutus.php';
                break;
            case 5:
                include './gallery/gallery.php';
                break;
            case 6:
                include './login/register.php';
                break;
            case 7:
                include './login/login.php';
                break;
            case 8:
                $_SESSION['user_id'] = null;
                include 'home.php';
                break;
            default:
                echo "<h1>Error 404</h1><p>Page not found!</p>";
        }
    }
    ?>
</main>
<footer>
    <p>Copyright &copy; 2024 Ivan Đakovac
        <a href="https://github.com/" target="_blank" title="Github">
            <img src="images/github.png" height="15" width="15" alt="Github" />
        </a>
    </p>
</footer>
</body>
</html>
