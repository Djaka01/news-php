<?php
include 'database.php';
global $conn;
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./login/login.css">
    <title>Registracija</title>
</head>
<body>
<section class="contact-form">
    <h2>Forma za registraciju</h2>

    <?php
    if (!isset($_POST['_action_']) || $_POST['_action_'] == FALSE) {
        $query = "SELECT * FROM Drzava";
        $countries = $conn->query($query);
        ?>
        <form action="" method="POST">
            <input type="hidden" name="_action_" value="TRUE">
            <input type="text" name="ime" placeholder="Ime" required>
            <input type="text" name="prezime" placeholder="Prezime" required>
            <input type="email" name="email" placeholder="Email" required>

            <select name="drzava" id="drzava" required>
                <option value="">Molimo odaberite</option>
                <?php
                if ($countries) {
                    while ($row = $countries->fetch_assoc()) {
                        echo '<option value="' . $row['id'] . '">' . $row['naziv'] . '</option>';
                    }
                } else {
                    die("Greška u SQL upitu: " . $conn->error);
                }
                ?>
            </select>

            <input type="text" name="grad" placeholder="Grad" required>
            <input type="text" name="ulica" placeholder="Ulica" required>
            <input type="date" name="datum_rodenja" required>
            <input type="password" name="lozinka" placeholder="Lozinka" required>
            <button type="submit">Registriraj se</button>
        </form>
        <?php
    } else {
        $ime = $_POST['ime'];
        $prezime = $_POST['prezime'];
        $email = $_POST['email'];
        $drzava = $_POST['drzava'];
        $grad = $_POST['grad'];
        $ulica = $_POST['ulica'];
        $datum_rodenja = $_POST['datum_rodenja'];
        $lozinka = password_hash($_POST['lozinka'], PASSWORD_DEFAULT);

        $korisnicko_ime = strtolower(substr($ime, 0, 1) . $prezime);


        $query = "SELECT COUNT(*) FROM Korisnik WHERE korisnicko_ime = ?";
        $stmt_check = $conn->prepare($query);
        if (!$stmt_check) {
            die("Greška u pripremi SELECT upita: " . $conn->error);
        }
        $stmt_check->bind_param("s", $korisnicko_ime);
        if (!$stmt_check->execute()) {
            die("Greška u izvršavanju SELECT upita: " . $stmt_check->error);
        }
        $stmt_check->bind_result($count);
        $stmt_check->fetch();

        $stmt_check->close();

        if ($count > 0) {
            $korisnicko_ime .= rand(100, 999);
        }

        $query_insert = "INSERT INTO Korisnik (ime, prezime, mail, id_drzava, grad, ulica, datum_rodenja, korisnicko_ime, lozinka) VALUES ('$ime','$prezime','$email','$drzava','$grad','$ulica','$datum_rodenja','$korisnicko_ime','$lozinka')";

        $query_insert = $conn->real_escape_string($query_insert);

        if($conn->query(stripslashes($query_insert))) {
            echo "Registracija uspješna!";
        } else {
            echo "Registracija nije uspjela, pokušajte ponovno!";
        }

    }
    ?>
</section>
</body>
</html>
