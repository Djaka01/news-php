<?php
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'PhpBaza';

    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        die("Konekcija s bazom nije uspjela: " . $conn->connect_error);
    } else {
        echo "Konekcija uspješna";
    }
?>
