<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Projektni zadatak 5 opis">
    <meta name="keywords" content="HTML5, css, projekt, zadatak">
    <meta name="author" content="Ivan Đakovac">
    <link rel="stylesheet" href="./gallery/gallery.css">
    <title>Projektni zadatak</title>
</head>
<div>
    <h1>Gallery</h1>
    <section class="gallery">
        <figure>
            <a href="./images/facebook.jpg" target="_blank">
                <img src="./images/facebook.jpg" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
        <figure>
            <a href="./images/github.png" target="_blank">
                <img src="./images/github.png" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
        <figure>
            <a href="./images/image.png" target="_blank">
                <img src="./images/image.png" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
        <figure>
            <a href="./images/linkedin.png" target="_blank">
                <img src="./images/linkedin.png" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
        <figure>
            <a href="./images/news1.jpg" target="_blank">
                <img src="./images/news1.jpg" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
        <figure>
            <a href="./images/news2.jpeg" target="_blank">
                <img src="./images/news2.jpeg" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
        <figure>
            <a href="./images/news3.jpg" target="_blank">
                <img src="./images/news3.jpg" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
        <figure>
            <a href="./images/news4.jpeg" target="_blank">
                <img src="./images/news4.jpeg" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
        <figure>
            <a href="./images/news5.jpeg" target="_blank">
                <img src="./images/news5.jpeg" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
        <figure>
            <a href="./images/twitter.svg" target="_blank">
                <img src="./images/twitter.svg" alt="Nice Elephant">
            </a>
            <figcaption>
                <p>Generički opis slike: prikaz neodređenog pejzaža ili scene.</p>
            </figcaption>
        </figure>
    </section>
</div>
</html>
