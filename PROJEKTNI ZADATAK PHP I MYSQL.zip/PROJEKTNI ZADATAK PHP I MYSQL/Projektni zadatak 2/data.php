<?php
$articles = [
    [
        'id' => 1,
        'title' => 'Bjelica: Ispred PSG-a smo, a molimo Boga da ne padne kiša da možemo trenirati',
        'date' => '25.11.2024.',
        'image' => './images/news1_1.jpg',
        'shortContent' => 'Dinamo je petom kolu Lige prvaka na Maksimiru izgubio 3:0 od Borussije Dortmund. Aktualni europski doprvak lako se obračunao s hrvatskim prvakom te poveo pred kraj prvog poluvremena pogotkom Jamieja Gittensa, da bi pobjedu u drugom dijelu podebljali Ramy Bensebaini i Serhou Guirassy. Dinamov trener Nenad Bjelica na konferenciji za medije komentirao je susret.',
        'content' =>'Dinamo je petom kolu Lige prvaka na Maksimiru izgubio 3:0 od Borussije Dortmund. Aktualni europski doprvak lako se obračunao s hrvatskim prvakom te poveo pred kraj prvog poluvremena pogotkom Jamieja Gittensa, da bi pobjedu u drugom dijelu podebljali Ramy Bensebaini i Serhou Guirassy. Dinamov trener Nenad Bjelica na konferenciji za medije komentirao je susret.
        
        Čestitke Borussiji na zasluženoj pobjedi. Bili su bolja momčad. Dominirali su, imaju jako puno kvalitete, teško nam je bilo igrati protiv njih. Čestitao bih i svojoj ekipi na borbenosti i disciplini. Ispunili su sve što smo tražili, ali falilo nam je snage za nešto više. U ovom stanju u kojem smo danas istrčali nismo mogli dati više, a mislim da smo dali jako puno. Fokus je na sljedećoj utakmici i derbiju u Splitu. Drago mi je da smo dali nekim igračima minute i vidjeli smo da možemo računati na njih, drago mi je da je debitirao Branko Pavić, koji nam isto postaje opcija. Cilj je bio da vidimo kako se on snalazi u ovoj atmosferi u utakmici u kojoj nije bilo previše rizika. Čestitke Kačavendi, Stojkoviću i Rogu, koji su bez minuta odigrali jako dobru utakmicu, pa i Bernaueru, koji je unatoč svim vašim kritikama, pokazao da i trkački i igrački može pomoći na toj poziciji.

Nisko smo se branili, teško je istrčati kontru od 50-60 metara. Pokušali smo dat svoj maksimum. U dvije-tri situacije smo se približili šesnaestercu i imali udarce, ali to je premalo na ovom nivou. Nemam što zamjeriti svojim igračima. Protiv ovog protivnika, koji će, po meni, biti među prvih osam u Ligi prvaka, bilo je jako teško. Moramo prihvatiti da su razlike velike između njih i nas.

Možda i je, pogreške su dio mog posla. Mislili smo da ćemo s ovim igračima doći do dobrog rezultata. Procijenili smo da moramo igrati s pet u obrani jer Borussia ima izrazito brze igrače. Ta petorka nam je donosila dobre rezultate. Nismo imali napadača pa smo se odlučili za ovu momčad. U nekim fazama je to jako dobro izgledalo.

Neću vam pričati o problemima koje imamo mi i Kulenović. Cijelo vrijeme igra s problemom i zadnjih par dana se nije dobro osjećao. Znajući da Bruno Petković u nedjelju neće biti ni na klupi, a možda ni do kraja polusezone, htjeli smo ga sačuvati za utakmicu koja nam je puno važnija.',
    ],
    [
        'id' => 2,
        'title' => 'Musk kritizirao način na koji funkcionira Europska unija',
        'date' => '25.11.2024.',
        'image' => './images/news2_1.jpg',
        'shortContent' => 'Elon Musk je kritizirao Europsku komisiju, nazvavši to tijelo "nedemokratskim", što je posljednja u nizu njegovih javnih kritika institucija i donošenja politika Europske unije. "Parlament EU-a trebao bi glasovati izravno o stvarima, a ne prepustiti ovlasti Europskoj komisiji", napisao je Musk na društvenim mrežama nakon što su članovi Europskog parlamenta dali zeleno svjetlo novoj Komisiji.',
        'content' => 'Elon Musk je kritizirao Europsku komisiju, nazvavši to tijelo "nedemokratskim", što je posljednja u nizu njegovih javnih kritika institucija i donošenja politika Europske unije. "Parlament EU-a trebao bi glasovati izravno o stvarima, a ne prepustiti ovlasti Europskoj komisiji", napisao je Musk na društvenim mrežama nakon što su članovi Europskog parlamenta dali zeleno svjetlo novoj Komisiji.

Glasalo je 688 zastupnika, od toga njih 370 je glasalo za potvrđivanje Komisije, 282 bilo je protiv, a 36 suzdržanih. Novu Komisiju čine predsjednica Ursula von der Leyen i 26 povjerenika. Povjerenike, po jednog iz svake članice, imenovale su nacionalne vlade, a zatim im je von der Leyen dodijelila portfelje.

Musk je u više navrata komentirao političke procese u drugim zemljama ili organizacijama. U listopadu se posvađao s potpredsjednicom Europske komisije na odlasku Verom Jourovom, nazvavši je "utjelovljenjem banalnog, birokratskog zla” nakon što je ona za njega rekla da je "promotor zla".

Muskov politički angažman doživio je eksponencijalni skok ovog ljeta kada je podržao Trumpovu kandidaturu za predsjednika SAD-a i uložio milijune dolara u financiranje Trumpove kampanje, piše Politico.

Postao je blizak savjetnik novoizabranog predsjednika, čak se uključio u Trumpov razgovor s ukrajinskim predsjednikom Volodimirom Zelenskim i navodno se sastao s iranskim izaslanikom u Ujedinjenim narodima.',
    ],
    [
        'id' => 3,
        'title' => 'Ukrajinski zastupnik nominirao Trumpa za Nobelovu nagradu za mir ',
        'date' => '25.11.2024.',
        'image' => './images/news3_1.jpg',
        'shortContent' => 'Oleksandr Merežko, ukrajinski zastupnik iz stranke Volodimira Zelenskog, nominirao je novoizabranog predsjednika SAD-a Donalda Trumpa za Nobelovu nagradu za mir 2025. godine. Kyiv Independent imao je uvid u pismo koje je poslao norveškom Nobelovom odboru.',
        'content' => 'Oleksandr Merežko, ukrajinski zastupnik iz stranke Volodimira Zelenskog, nominirao je novoizabranog predsjednika SAD-a Donalda Trumpa za Nobelovu nagradu za mir 2025. godine. Kyiv Independent imao je uvid u pismo koje je poslao norveškom Nobelovom odboru. Ovaj potez u suprotnosti je s izjavama mnogih ukrajinskih dužnosnika koji su kritizirala Trumpa jer je hvalio ruskog predsjednika Vladimira Putina i dovodio u pitanje daljnju pomoć Sjedinjenih Država Ukrajini. Trump je obećao posredovati u mirovnom sporazumu za okončanje rata u Ukrajini, a Ukrajinci strahuju kako bi mogao izvršiti pritisak na Kijev da ustupi teritorij Rusiji ili pristane na Putinove uvjete.

Međutim, neki ukrajinski političari i analitičari tvrde da bi Trump mogao pomoći Kijevu da postigne povoljan mirovni sporazum s Rusijom. "Vjerujem da je Trump znatno pridonio svjetskom miru i da može učiniti još više u budućnosti", napisao je Merežko, koji obnaša i dužnost predsjednik vanjskopolitičkog odbora ukrajinskog parlamenta.

Spomenuo je Trumpovo posredovanje u sporazumima između Izraela i muslimanskih zemalja, uključujući Ujedinjene Arapske Emirate, Bahrein i Sudan, tijekom njegovog prvog predsjedničkog mandata.

"Trump je također postavio temelje za današnju međunarodnu koaliciju potpore Ukrajini demonstrirajući globalno vodstvo u opskrbi oružjem za otpor ruskom brutalnom i nezakonitom agresorskom ratu", naglasio je Merežko u očitom referiranju na Trumpovu odluku da opskrbi Ukrajinu protutenkovskim projektilima Javelin tijekom svog prvog mandata.

Izrazio je nadu da će Trump "u svojim pokušajima da zaustavi agresiju Rusije protiv Ukrajine tražiti rješenje na temelju međunarodnog prava, uključujući principe kao što su teritorijalni integritet, poštivanje suvereniteta Ukrajine i neuporaba sile".',
    ],
    [
        'id' => 4,
        'title' => 'Plenkovićev savjetnik: Nije točno da su cijene pojele rast plaća ',
        'date' => '25.11.2024.',
        'image' => './images/news4_1.jpg',
        'shortContent' => '"Gospodarski rast od 3.9 posto je najviša stopa gospodarskog rasta od svih država. Ovo je jako lijepa i pozitivna vijest. Ti trendovi već neko vrijeme traju, to je već 15. kvartal u nizu, što znači da od početka 2021. Hrvatska nije zabilježila nijedan kvartal pada. To vam može manje od polovice država Unije potvrditi za sebe", započeo je Zvonimir Savić.',
        'content' => 'Ministar obrane Ivan Anušić oštro je kritizirao europske vođe i njihovo vođenje europskih politika na tribini Sigurnosni i geopolitički izazovi svjetskog poretka u organizaciji Hrvatskog diplomatskog kluba. Tribina se održala jučer navečer, a Anušić, koji je tamo došao kao izaslanik premijera Andreja Plenkovića, održao je desetominutni govor u kojem je bio vrlo oštar. Izrazio je skepsu prema situaciji na istoku Europe te istaknuo da je Mađarska jednako opasna za Hrvatsku kao i Srbija.

Na početku je kazao da se slaže s tvrdnjama da Europa više nema lidera te je počeo kritizirati europsku politiku. "Dvadeset godina europska politika u potpunosti je promašena. To je ružičasta politika. To je liberalna politika, protiv koje ja nemam ništa, ali imam protiv njihova stava kada govorimo o obrani, o temeljima svake države i temeljima kršćanstva na kojima Europa počiva i koje je ta Europa polako napustila.

Napustila ih je odlazeći prema, kako ja zovem, ružičastoj politici u kojoj svi nose ružičaste naočale. Misle da su svi super, da su svi dobronamjerni, da su svi dobrodošli i da se ne moramo brinuti za budućnost, da ne moramo razvijati vojsku, kupovati oružje i raditi na sigurnosti. I gdje nas je to odvelo!?" upitao je Anušić te zaključio da je to rezultiralo današnjom situacijom u Europi.

"S druge strane gledale su nas politike s istoka i točno su znale što radimo. Ne radimo ništa. A oni su radili i spremali se za ovo. U ovom trenutku podaci koji stižu s bojišta, iz Rusije, i podaci koji stižu iz Europe poražavajući su za Europu. Mi uopće ne možemo stići njihovu proizvodnju naoružanja. Ekonomski im ne možemo ništa. Nikakve sankcije na njih ne djeluju.

Rusiji čak raste BDP, a Europa ovisi o politici Sjedinjenih Američkih Država", rekao je Anušić i zaključio: "Kao Europa doveli smo se u situaciju da smo možda najslabija karika u podjeli vlasti, u podjeli snaga, u podjeli utjecaja."',
    ],
    [
        'id' => 5,
        'title' => 'Anušić: Rusiji ne možemo ništa, a što radi EU? Daje novac za robotaksije i maslačke ',
        'date' => '25.11.2024.',
        'image' => './images/news5_1.jpg',
        'shortContent' => 'Ministar obrane Ivan Anušić oštro je kritizirao europske vođe i njihovo vođenje europskih politika na tribini Sigurnosni i geopolitički izazovi svjetskog poretka u organizaciji Hrvatskog diplomatskog kluba.',
        'content' => 'Ministar obrane Ivan Anušić oštro je kritizirao europske vođe i njihovo vođenje europskih politika na tribini Sigurnosni i geopolitički izazovi svjetskog poretka u organizaciji Hrvatskog diplomatskog kluba. Tribina se održala jučer navečer, a Anušić, koji je tamo došao kao izaslanik premijera Andreja Plenkovića, održao je desetominutni govor u kojem je bio vrlo oštar. Izrazio je skepsu prema situaciji na istoku Europe te istaknuo da je Mađarska jednako opasna za Hrvatsku kao i Srbija.

Na početku je kazao da se slaže s tvrdnjama da Europa više nema lidera te je počeo kritizirati europsku politiku. "Dvadeset godina europska politika u potpunosti je promašena. To je ružičasta politika. To je liberalna politika, protiv koje ja nemam ništa, ali imam protiv njihova stava kada govorimo o obrani, o temeljima svake države i temeljima kršćanstva na kojima Europa počiva i koje je ta Europa polako napustila.

Napustila ih je odlazeći prema, kako ja zovem, ružičastoj politici u kojoj svi nose ružičaste naočale. Misle da su svi super, da su svi dobronamjerni, da su svi dobrodošli i da se ne moramo brinuti za budućnost, da ne moramo razvijati vojsku, kupovati oružje i raditi na sigurnosti. I gdje nas je to odvelo!?" upitao je Anušić te zaključio da je to rezultiralo današnjom situacijom u Europi.

"S druge strane gledale su nas politike s istoka i točno su znale što radimo. Ne radimo ništa. A oni su radili i spremali se za ovo. U ovom trenutku podaci koji stižu s bojišta, iz Rusije, i podaci koji stižu iz Europe poražavajući su za Europu. Mi uopće ne možemo stići njihovu proizvodnju naoružanja. Ekonomski im ne možemo ništa. Nikakve sankcije na njih ne djeluju.

Rusiji čak raste BDP, a Europa ovisi o politici Sjedinjenih Američkih Država", rekao je Anušić i zaključio: "Kao Europa doveli smo se u situaciju da smo možda najslabija karika u podjeli vlasti, u podjeli snaga, u podjeli utjecaja."',
    ],
];
?>