<?php
global $articles;
include './data.php';
$id = isset($_GET['articleId']) ? intval($_GET['articleId']) : 0;

$current_article = null;
foreach ($articles as $article) {
    if ($article['id'] === $id) {
        $current_article = $article;
        break;
    }
}
if ($current_article):
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Projektni zadatak 5 opis">
    <meta name="keywords" content="HTML5, css, projekt, zadatak">
    <meta name="author" content="Ivan Đakovac">
    <link rel="stylesheet" href="./news/news.css">
    <title>Projektni zadatak</title>
</head>
<body>
    <h1><?php echo $current_article['title']; ?></h1>
    <p class="date">Published: <?php echo $current_article['date']; ?></p>
    <img src="<?php echo $current_article['image']; ?>" alt="Article Image">
    <p class="paragraph"><?php echo $current_article['content']; ?></p>
    <a href="?menu=2" class="back-link">Back to News</a>
    <?php else: ?>
        <h1>Article not found</h1>
        <p>We couldn't find the article you're looking for.</p>
        <a href="?menu=2" class="back-link">Back to News</a>
    <?php endif; ?>
</body>

