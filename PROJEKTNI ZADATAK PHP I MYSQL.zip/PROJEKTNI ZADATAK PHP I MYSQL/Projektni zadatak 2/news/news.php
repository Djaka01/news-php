<?php
global $articles;
include './data.php';
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Projektni zadatak 5 opis">
    <meta name="keywords" content="HTML5, css, projekt, zadatak">
    <meta name="author" content="Ivan Đakovac">
    <link rel="stylesheet" href="./news/news.css">
    <title>Projektni zadatak</title>
</head>
<h1>News</h1>
<section class="articles">
    <?php foreach ($articles as $article): ?>
    <article>
        <img src="<?php echo $article['image']; ?>" alt="Article Image">
        <div>
            <h2><a href="?articleId=<?php echo $article['id'];?>"><?php echo $article['title']; ?></a></h2>
            <p class="date">Published: <?php echo $article['date']; ?></p>
            <p><?php echo $article['content']; ?></p>
            <a href="?articleId=<?php echo $article['id']; ?>" class="read-more">Read more...</a>
        </div>
    </article>
    <?php endforeach; ?>
</section>
